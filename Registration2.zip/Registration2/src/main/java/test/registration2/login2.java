/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test.registration2;

import java.util.Scanner;


   public class login2 {
   Scanner input = new Scanner(System.in);
    
   // variables used to store user details
    private String capturedName;
    private String username;
    private String Password;
    
   public String Names(){
   System.out.print("Enter your First Name : ");
   String Name = input.nextLine();
   System.out.print("Enter your Last Name  : ");
   String Surname = input.nextLine();
   capturedName = Name + " " + Surname; 
   return Name + " " + Surname;
   
   }
   
   public String Username(){
    //prompt user 
    System.out.print("Enter your Username   : ");
     username = input.nextLine();
    return username;
    
    }
   
   public String Password(){
       
    System.out.print("Enter Password        : ");
    Password = input.nextLine();   
   return Password;
   }
   public String CellNumber (){
       
    System.out.print("Enter your number     : ");
    String number  = input.nextLine();  
    return number ;
   }
       public void loginUser() {
          
        System.out.println("\n=== LOGIN ===");
      
        int counter =1;
        boolean loggedIn = false;
        while (counter<=3 &&!loggedIn ){
            
        System.out.print("\nEnter username : " );
        String Username = input.nextLine();
        System.out.print("Enter password : ");
        String Pass = input.nextLine();
                
            
    if (Username.equals(username) && Pass.equals(Password)){
    System.out.println("Welcome " + capturedName + " it is great to see you again." );
    loggedIn =true;
    }
    else{
    System.out.print("Username or password incorrect. Try again.");
    }
     
      counter = counter +1 ;
    }
       if (!loggedIn) {
    System.out.print("\n\nToo many attempts, Try again later");
    System.exit(0);
}
       }
  // method to return message after logging in 
       public String returnLoginStatus(boolean loginStatus){

    if(loginStatus){
        return "Welcome " + capturedName + " it is great to see you again.";
    }
    else{
        return "Username or password incorrect, please try again.";
    }

}
   //validation

   
 public void validate (String username,String Password,String CellNumber){
 
 boolean ValidUsername = checkUserName(username);
 boolean ValidPassword = checkPasswordComplexity(Password);
 boolean ValidPhoneNumber = checkCellPhoneNumber(CellNumber);
 
      if(ValidUsername  )
      {
      System.out.println("Username successfully captured");
      }
      else {
      System.out.println("Username is not correctly formatterd;please ensure that your username contains an underscore and is no more than five characters in length.  ");
      }
      if( ValidPassword )      
      {
      System.out.println("Password successfully captured");    
      }
      else{
       System.out.println("Password is not correctly formatted;please ensure that the password contains at least eight characters,a capital letter,a number,and a special character.");
      }
      
      if(ValidPhoneNumber ){
      System.out.println("Cell phone number successfully added");
      }
      else{
      System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
      }
          
      if(ValidUsername && ValidPassword && ValidPhoneNumber){ System.out.print("Registration Successful\n\n ");  
      loginUser ();
      }
      
      else{System.out.print("\nRegistration failed,please Register again.");
      System.exit(0);
      }
 }
   
   
public static boolean checkUserName(String username){
    return username.contains("_") && username.length()<=5;
}

public static boolean checkPasswordComplexity(String password){
    return password.matches("^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+=!]).{8,}$");
}

public static boolean checkCellPhoneNumber(String cellNumber){
    
    return cellNumber.matches("^\\+27[0-9]{9}$");
}

   }